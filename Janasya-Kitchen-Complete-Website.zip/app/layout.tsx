import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Janasya's Kitchen | Wings, Sweets & Catering", description: "Order Wing Wednesday meals, Soul Food Sunday plates, sweets, weekly specials, and catering in Douglas, Georgia." };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
