JANASYA'S KITCHEN — CLEAN WEBSITE ZIP

FILES
- index.html — full website, wing menu, sweets, cart, quantities and checkout
- style.css — mobile-friendly design and fixed Mini Cakes layout
- script.js — working Add to Cart, quantities, totals, remove buttons and text-message checkout
- admin.html — owner reply tool for sending Order Received / Preparing / Ready text messages

WHAT WAS FIXED
- Working Add to Cart buttons
- Quantity selectors for wing meals and sweets
- Wing flavor selector
- Drink selector
- Regular Fries / Loaded Fries selector
- Mini Cakes layout fixed so Small and Large no longer squeeze together
- Cart count and total update correctly
- Remove items and Clear Cart functions
- Checkout creates a complete text-message order
- Owner page can open a prepared text to notify a customer when you have read their order

IMPORTANT ABOUT “ORDER READ”
This is a static GitHub/Netlify website. A static site cannot automatically know when the business owner reads a customer's text message. admin.html gives the owner a one-tap prepared reply. Fully automatic read-status SMS would require a backend/database and a texting provider such as Twilio.

HOW TO UPLOAD TO GITHUB
1. Unzip this folder.
2. In your GitHub Janasyas-kitchen repository, replace the old index.html, style.css and script.js with these files.
3. Add admin.html too.
4. Commit/save the changes.
5. Wait for Netlify/GitHub deployment to update.
6. Refresh janasyaskitchen.com and test Add to Cart and checkout.

OWNER TOOL
Open: https://janasyaskitchen.com/admin.html
Enter the customer's phone number, then choose Order Received / Preparing / Ready.
