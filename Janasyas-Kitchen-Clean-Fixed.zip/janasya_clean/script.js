(() => {
  'use strict';

  const BUSINESS_PHONE = '19125929236';
  const CART_KEY = 'janasyasKitchenCartV2';
  let cart = loadCart();

  const $ = (id) => document.getElementById(id);
  const money = (value) => `$${Number(value).toFixed(2)}`;

  function loadCart() {
    try {
      const saved = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      return Array.isArray(saved) ? saved : [];
    } catch {
      return [];
    }
  }

  function saveCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }

  function value(id) {
    const el = $(id);
    return el ? el.value : '';
  }

  function qty(id) {
    const el = $(id);
    const parsed = el ? parseInt(el.value, 10) : 1;
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
  }

  function addItem(name, price, quantity = 1) {
    const q = Math.max(1, parseInt(quantity, 10) || 1);
    const existing = cart.find((item) => item.name === name && Number(item.price) === Number(price));
    if (existing) existing.qty += q;
    else cart.push({ name, price: Number(price), qty: q });
    saveCart();
    renderCart();
    showToast(`${q} added to cart`);
  }

  function handleAdd(action) {
    const actions = {
      wing5: () => addItem(
        `5 Piece Wing Meal — ${value('wing5Flavor')} — Drink: ${value('wing5Drink')} — Fries: ${value('wing5Fries')}`,
        10,
        qty('wing5Qty')
      ),
      wing10: () => addItem(
        `10 Piece Wing Meal — ${value('wing10Flavor')} — Drink: ${value('wing10Drink')} — Fries: ${value('wing10Fries')}`,
        15,
        qty('wing10Qty')
      ),
      cakeSmall: () => addItem(`Small ${value('cakeFlavor')} Mini Cake`, 2.5, qty('cakeSmallQty')),
      cakeLarge: () => addItem(`Large ${value('cakeFlavor')} Mini Cake`, 4, qty('cakeLargeQty')),
      cookie: () => addItem(`${value('cookieFlavor')} Cookie`, 2, qty('cookieQty')),
      brownie: () => addItem('Brownie', 1.5, qty('brownieQty')),
      rice: () => addItem('Rice Krispie Treat', 2, qty('riceQty')),
      pretzel: () => addItem('Chocolate Covered Pretzel', 1, qty('pretzelQty')),
      oreoBalls: () => addItem('Oreo Balls — 3 Count', 5, qty('oreoBallsQty')),
      straw6: () => addItem('Chocolate Covered Strawberries — 6 Count', 12, qty('straw6Qty')),
      straw12: () => addItem('Chocolate Covered Strawberries — 12 Count', 24, qty('straw12Qty')),
      straw24: () => addItem('Chocolate Covered Strawberries — 24 Count', 48, qty('straw24Qty'))
    };
    if (actions[action]) actions[action]();
  }

  function renderCart() {
    const cartItems = $('cartItems');
    const cartCount = $('cartCount');
    const cartTotal = $('cartTotal');
    if (!cartItems || !cartCount || !cartTotal) return;

    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    cartCount.textContent = count;
    cartTotal.textContent = money(total);

    if (!cart.length) {
      cartItems.innerHTML = '<div class="empty-cart">Your cart is empty.</div>';
      return;
    }

    cartItems.innerHTML = cart.map((item, index) => `
      <div class="cart-item">
        <div class="cart-item-top">
          <strong>${escapeHtml(item.name)}</strong>
          <button class="remove-item" type="button" data-remove="${index}">Remove</button>
        </div>
        <p>Qty: ${item.qty} • ${money(item.price)} each</p>
        <p><strong>${money(item.price * item.qty)}</strong></p>
      </div>
    `).join('');
  }

  function escapeHtml(text) {
    return String(text)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function openCart() {
    $('cartDrawer')?.classList.add('open');
    $('cartDrawer')?.setAttribute('aria-hidden', 'false');
    $('cartOpen')?.setAttribute('aria-expanded', 'true');
    if ($('overlay')) $('overlay').hidden = false;
  }

  function closeCart() {
    $('cartDrawer')?.classList.remove('open');
    $('cartDrawer')?.setAttribute('aria-hidden', 'true');
    $('cartOpen')?.setAttribute('aria-expanded', 'false');
    if ($('overlay')) $('overlay').hidden = true;
  }

  let toastTimer;
  function showToast(message) {
    const toast = $('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1700);
  }

  function formatOrder() {
    const name = value('customerName').trim();
    const phone = value('customerPhone').trim();
    const pickup = value('pickupTime').trim();
    const notes = value('orderNotes').trim();
    const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    const lines = cart.map((item) => `• ${item.qty}x ${item.name} — ${money(item.price * item.qty)}`);
    return [
      `Hi! I would like to place an order with Janasya's Kitchen.`,
      '',
      `Name: ${name}`,
      `Customer phone: ${phone}`,
      `Pickup: ${pickup}`,
      '',
      'ORDER:',
      ...lines,
      '',
      `Total: ${money(total)}`,
      `Notes: ${notes || 'None'}`
    ].join('\n');
  }

  document.querySelectorAll('.add-button').forEach((button) => {
    button.addEventListener('click', () => handleAdd(button.dataset.item));
  });

  $('cartItems')?.addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove]');
    if (!button) return;
    const index = Number(button.dataset.remove);
    if (!Number.isInteger(index)) return;
    cart.splice(index, 1);
    saveCart();
    renderCart();
  });

  $('clearCart')?.addEventListener('click', () => {
    cart = [];
    saveCart();
    renderCart();
  });

  $('cartOpen')?.addEventListener('click', openCart);
  $('cartClose')?.addEventListener('click', closeCart);
  $('overlay')?.addEventListener('click', closeCart);
  $('checkoutJump')?.addEventListener('click', closeCart);

  $('checkoutForm')?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!cart.length) {
      showToast('Add something to your cart first');
      openCart();
      return;
    }
    if (!event.currentTarget.reportValidity()) return;
    const message = formatOrder();
    const smsUrl = `sms:${BUSINESS_PHONE}?&body=${encodeURIComponent(message)}`;
    window.location.href = smsUrl;
  });

  renderCart();
})();
